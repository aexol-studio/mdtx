import React from 'react';

export const SampleAtom = () => {
  return <div>SampleAtom</div>;
};
