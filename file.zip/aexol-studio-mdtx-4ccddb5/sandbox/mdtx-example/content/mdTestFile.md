---
link: changelog
title: Changelog
order: 99
---

:dog: :girl: Elosdfsdaiosdfjgdikjdfgdfgnsdksdjkfj :cat: :dog: :boy:

# Markdown syntax guide

## Headers

# This is a Heading h1

## This is a Heading h2

### This is a

#### This is a Heading h4

##### This is a test Heading h5

###### This is a Heading h6

## Emphasis

_This text will be italic_  
_This will also be italic_

**This text will be bold**  
**This will also be bold**

_You **can** combine them_

## Lists

### Unordered

- Item 1
- Item 2
- Item 2a
- Item 2b

### Ordered

1. Item 1
1. Item 2
1. Item 3
1. Item 3a
1. Item 3b

## Images

![This is a alt text.](/aexol_full_logo.png "This is a sample image.")

## Links

You may be using [Markdown Live Preview](https://markdownlivepreview.com/).

## Blockquotes

> Markdown is a lightweight markup language with plain-text-formatting syntax, created in 2004 by John Gruber with Aaron Swartz.
>
> > Markdown is often used to format readme files, for writing messages in online discussion forums, and to create rich text using a plain text editor.

## Tables

| Syntax    | Description |
| --------- | ----------- |
| Header    | Title       |
| Paragraph | Text        |

## Blocks of code

```
let message = 'Hello world';
alert(message);
```

## Inline code

This web site is using `aexol-studio/mdtx`.
