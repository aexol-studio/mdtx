# Next.js + Tailwind CSS + MDtx example
