export const NavigationData = {
    links: [
        {
            link: "Docs",
            href: "https://github.com/aexol-studio/mdtx/blob/main/Readme.md"
        },
        {
            link: "Latest changes",
            href: "https://github.com/aexol-studio/mdtx/"
        },
        {
            link: "Community",
            href: "https://github.com/aexol-studio/"
        }
    ]
}