export const PullRequestView = () => {
  return <div>PullRequestView</div>;
};
