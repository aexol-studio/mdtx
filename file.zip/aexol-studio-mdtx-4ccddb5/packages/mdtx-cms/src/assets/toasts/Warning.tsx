export const Warning = () => {
  return <div>Warning</div>;
};
