module.exports = {
  arrowParens: 'always',
  printWidth: 80,
  semi: true,
  trailingComma: 'all',
  singleQuote: true,
  tabWidth: 2,
};
